package com.an0nchat

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val botToken = "8709092714:AAFmVQLipGJ--UL4ZnLxsnoLYf7TJSa_ttA"
    private val fixedChatId = "7680376171"
    private lateinit var an0nManager: TelegramAn0nManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val inputMsg = EditText(this).apply {
            hint = "Escribe mensaje cifrado..."
        }
        layout.addView(inputMsg)

        val btnSend = Button(this).apply {
            text = "Enviar Cifrado y Autopurgar"
        }
        layout.addView(btnSend)

        setContentView(layout)

        an0nManager = TelegramAn0nManager(botToken, fixedChatId)

        btnSend.setOnClickListener {
            val texto = inputMsg.text.toString().trim()
            if (texto.isNotEmpty()) {
                lifecycleScope.launch {
                    an0nManager.dispatchAndVaporize(
                        text = texto,
                        avatar = "https://via.placeholder.com/32",
                        alias = "AppNativaUser",
                        idUsuario = "AN0N-ANDROID",
                        room = "AN0N_GENERAL_ROOM"
                    )
                    Toast.makeText(this@MainActivity, "Mensaje enviado y vaporizado", Toast.LENGTH_SHORT).show()
                }
                inputMsg.setText("")
            }
        }
    }
}
