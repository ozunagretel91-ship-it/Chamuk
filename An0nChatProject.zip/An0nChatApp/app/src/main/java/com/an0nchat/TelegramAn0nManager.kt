package com.an0nchat

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class TelegramAn0nManager(private val botToken: String, private val chatId: String) {

    companion object {
        private const val TAG = "An0nManager"
    }

    private fun encodeProtocol(text: String, avatar: String, alias: String, idUsuario: String, room: String): String {
        val obj = JSONObject().apply {
            put("room", room)
            put("alias", alias)
            put("avatar", avatar)
            put("idUsuario", idUsuario)
            put("text", text)
        }
        val raw = obj.toString()
        val hex = StringBuilder()
        for (element in raw) {
            val hexChar = String.format("%04x", element.code)
            hex.append(hexChar)
        }
        return "AN0N_PROTO_v17>>ENC[$hex]"
    }

    suspend fun dispatchAndVaporize(text: String, avatar: String, alias: String, idUsuario: String, room: String) {
        val encodedPayload = encodeProtocol(text, avatar, alias, idUsuario, room)
        
        withContext(Dispatchers.IO) {
            try {
                val messageId = sendTelegramMessage(encodedPayload)
                if (messageId != -1) {
                    vaporize(messageId)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error en el envío autónomo: ${e.message}")
            }
        }
    }

    private fun sendTelegramMessage(payload: String): Int {
        val url = URL("https://api.telegram.org/bot$botToken/sendMessage")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json; utf-8")
            conn.doOutput = true

            val jsonBody = JSONObject().apply {
                put("chat_id", chatId)
                put("text", payload)
            }

            OutputStreamWriter(conn.outputStream).use { it.write(jsonBody.toString()) }

            if (conn.responseCode == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val jsonRes = JSONObject(response)
                if (jsonRes.getBoolean("ok")) {
                    return jsonRes.getJSONObject("result").getInt("message_id")
                }
            }
        } finally {
            conn.disconnect()
        }
        return -1
    }

    private fun vaporize(msgId: Int) {
        val url = URL("https://api.telegram.org/bot$botToken/deleteMessage")
        for (i in 0..2) {
            var conn: HttpURLConnection? = null
            try {
                conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json; utf-8")
                conn.doOutput = true

                val jsonBody = JSONObject().apply {
                    put("chat_id", chatId)
                    put("message_id", msgId)
                }

                OutputStreamWriter(conn.outputStream).use { it.write(jsonBody.toString()) }

                if (conn.responseCode == 200) {
                    break
                }
            } catch (e: Exception) {
                Log.d(TAG, "Intento de vaporización $i fallido")
            } finally {
                conn?.disconnect()
            }
            Thread.sleep(200)
        }
    }
}
